const products = [
  {
    id: 1,
    name: "Dark Haven تيشيرت أسود",
    price: 650,
    currency: "EGP",
    img: "https://i.imgur.com/6Q1rGk6.jpg",
  },
  {
    id: 2,
    name: "سلسلة Dark Haven المعدنية",
    price: 450,
    currency: "EGP",
    img: "https://i.imgur.com/NU68Hsx.jpg",
  },
  {
    id: 3,
    name: "كاب Dark Haven الرسمي",
    price: 350,
    currency: "EGP",
    img: "https://i.imgur.com/xtxFfd9.jpg",
  },
];

let cart = [];

function renderProducts() {
  const grid = document.getElementById("products-grid");
  grid.innerHTML = "";
  products.forEach((p) => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <img src="${p.img}" alt="${p.name}" />
      <h3>${p.name}</h3>
      <p>${p.currency} ${p.price}</p>
      <button onclick="addToCart(${p.id})">أضف للسلة</button>
    `;
    grid.appendChild(card);
  });
}

function addToCart(id) {
  cart.push(id);
  document.getElementById("cart-count").innerText = cart.length;
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("تم إضافة المنتج إلى السلة");
}

function scrollToProducts() {
  document.getElementById("products-grid").scrollIntoView({ behavior: "smooth" });
}

window.onload = () => {
  const stored = JSON.parse(localStorage.getItem("cart"));
  if (stored) cart = stored;
  document.getElementById("cart-count").innerText = cart.length;
  renderProducts();
};